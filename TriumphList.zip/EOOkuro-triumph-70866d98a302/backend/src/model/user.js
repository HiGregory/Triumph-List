import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const userSchema = new Schema({
  firstname: String,
  lastname: String,
  username: String,
  email: String,
  phonenumber: String,
  profilepicurl: String,
  passwordresettoken: String,
  tokenexpiration: String,
  isactivated: String, default: false,
  isAdmin: {
    type: Boolean,
    default: false
  }
},
  { timestamps: true }
);

module.exports = mongoose.model('User', userSchema);
