import mongoose from 'mongoose';
import { Router } from 'express';
import bodyParser from 'body-parser';
import Product from '../model/product';

import { authenticate } from '../middleware/authMiddleware';

export default ({config, db}) => {
  let api = Router();

    // '/v1/product/' - Create new product endpoint
    api.post('/',authenticate, (req, res) => {
      let product = new Product();
      product.partId = req.body.partId;
      product.partNumber = req.body.partNumber;
      product.partDescription = req.body.partDescription;
      product.basePartNumner = req.body.basePartNumner;
      product.airCraftSeries = req.body.airCraftSeries;
      product.airCraftModel = req.body.airCraftModel;
      product.engineType = req.body.engineType;
      product.ataNumber = req.body.ataNumber;

      product.save(err => {
        if (err) {
          res.status(500).json({ message: err });
          return;
        }
          res.status(200).json({message: product});
      });
    });

    // /v1/product/:id Read 1 product endpoint
  api.get('/:id', authenticate, (req, res) => {
    Product.find({id: req.params.id}, (err, product) => {
      if (!product) {
        const error = new Error('Could not find product.');
        error.statusCode = 404;
        throw error;
      }
      if (err) {
        res.status(500).json({message: `An error has occured: ${err.message}`});
        return;
      }
        res.status(200).json(product);
    });
  });


  // /v1/product/:id Update 1 product
  api.put('/:id', authenticate, (req, res) => {
    Product.findById(req.params.id, (err, product) => {
      if (!product) {
        const error = new Error('Could not find product.');
        error.statusCode = 404;
        throw error;
      }
      if (err) {
        res.status(500).json({message: `An error has occured: ${err.message}`});
        return;
      }
      product.partId = req.body.partId;
      product.partNumber = req.body.partNumber;
      product.partDescription = req.body.partDescription;
      product.basePartNumner = req.body.basePartNumner;
      product.airCraftSeries = req.body.airCraftSeries;
      product.airCraftModel = req.body.airCraftModel;
      product.engineType = req.body.engineType;
      product.ataNumber = req.body.ataNumber;

      product.save(err => {
          if (err) {
            res.status(500).json({message: `An error has occured: ${err.message}`});
            return;
          }
          res.status(200).json({message: 'Product updated successfully'});
      });
    });
  });

  // /v1/product/:partId Read 
  api.get('/:partId', authenticate, (req, res) => {
    Product.find({'partId': req.params.id}, (err, product) => {
      if (!product) {
        const error = new Error('Could not find product.');
        error.statusCode = 404;
        throw error;
      }
      if (err) {
        res.status(500).json({message: `An error has occured ${err.message}`});
        return;
      }
        res.status(200).json(product);
    });
  });

// TODO Implementation of pagination and refactor to use then and catch

  // /v1/product/all Read All Products
  api.get('/', authenticate, (req, res) => {
    Request.find({}, (err, products) => {
      if (err) {
        res.status(500).json({message: `An error has occured ${err.message}`});
        return;
      }
        res.status(200).json(request);
    });
  });

    return api;
}
