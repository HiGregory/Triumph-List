import mongoose from 'mongoose';
const Schema = mongoose.Schema;

const productSchema = new Schema({
  partId: {
    type: String,
    required: true
  },
  partNumber: {
    type: String,
    required: true
  },
  partDescription: {
    type: String,
    required: true
  },
  basePartNumner: {
    type: String,
    required: true
  },
  airCraftSeries: {
    type: String,
    required: true
  },
  airCraftModel: {
    type: String,
    required: true
  },
  engineType: {
    type: String,
    required: true
  },
  ataNumber: {
    type: String,
    required: true
  },
},
  { timestamps: true }
);

module.exports = mongoose.model('Product', productSchema);
