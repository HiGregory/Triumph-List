## Triumph 
Triumph is a inventory management system for airplane parts. We build the application with Node.js as an API backend and React.js as the client side facing application. 

##The Tools
**Node.js** is a JavaScript runtime platform based on the V8 engine that's also used in Chrome browsers.

It's single-threaded, but features a compicated event loop for processing of asynchronous events, giving the ability to handle tons of asynchronous tasks at the same time. A Node.js application will perform very poorly if you hog up this single thread. Try using asyncronous flavours of all I/O operations.

**React.js** is a JavaScript library for building user interfaces. React is declarative
Component based. You can develop new features without having to rewriting code, because React is only client side framework.

Make sure to check your Node version
```
node --version
```

## Clone a repository

Use these steps to clone from SourceTree, our client for using the repository command-line free. Cloning allows you to work on your files locally. If you don't yet have SourceTree, [download and install first](https://www.sourcetreeapp.com/). If you prefer to clone from the command line, see [Clone a repository](https://confluence.atlassian.com/x/4whODQ).

1. You’ll see the clone button under the **Source** heading. Click that button.
2. Now click **Check out in SourceTree**. You may need to create a SourceTree account or log in.
3. When you see the **Clone New** dialog in SourceTree, update the destination path and name if you’d like to and then click **Clone**.
4. Open the directory you just created to see your repository’s files.

Now that you're more familiar with your Bitbucket repository, go ahead and add a new file locally. You can [push your change back to Bitbucket with SourceTree](https://confluence.atlassian.com/x/iqyBMg), or you can [add, commit,](https://confluence.atlassian.com/x/8QhODQ) and [push from the command line](https://confluence.atlassian.com/x/NQ0zDQ).

###Before Running the project
**Git**Install =the latest Git for Windows installer [here](https://gitforwindows.org/).
Follow the Next and Finish prompts to complete the installation. The default options are pretty sensible for most users.

Open a Command Prompt (or Git Bash if during installation you elected not to use Git from the Windows Command Prompt).
```
$ git config --global user.name "First Name"
$ git config --global user.email "example@email.com"
```

**NPM & Node.js** Go to the offical node.js [website](https://nodejs.org/en/) donwload the installer as an `<.msi.` file. 
Keep the default settings make sure to pick NPM package manager. 
Open up Command Prompt and run `<npm -v>` and `<node -v>`to check if it is installed properlly, should return the version numbers. 

Next `<git clone your repo>` onto your machine. 

##Deployment

**Development**

[**Docker**](https://docs.docker.com/get-started/)

**Test**

[**Heroku:Vanilla**](https://devcenter.heroku.com/categories/nodejs-support) 

[**Heroku:Docker**](https://devcenter.heroku.com/categories/deploying-with-docker)
Heroku allows for two different strategies to deploy your applicaiton with [Docker](https://docs.docker.com/get-started/).

**Production**

[**Alpha Anywhere**](https://documentation.alphasoftware.com/documentation/pages/GettingStarted/index.html)

The Alpha Anywhere system has two ways to deploy applications. In this example we will be going over the Anywhere Application Server, the docs from Alpha Anywhere are available [here](https://documentation.alphasoftware.com/pages/Guides/Application%20Server/Server%20Settings/index.xml)

Download Alpha Anywhere you should receive that via email with a license number. 

Once downloaded, open up the Alpha Anywhere desktop application. The first thing you should see a black screen that looks like a black screen. 

￼￼￼[Inital Screen](Documentation/images/initailscreen.png)

Click on the Recent Workspaces tab and a prompt asking you to create a new workspace should pop up. 

￼[Prompt](Documentation/images/prompt.png)

The prompt will ask you if you would like to enter the Control Panel click Yes. 
Once in the Web Projects Control Panel on the top tab click the Web line and Start the Development Server. 


￼[Development Server](Documentation/images/devserver.png)

A HTTOP Demo Server should be deployed and you should go ahead and press start server. 

￼[Start Server](Documentation/images/startServer1.png)

If prompted, click Yes to confirm the action.

￼[Start Server](Documentation/images/startServer2.png)

If you want to Stop the server go back and the the same steps as starting but when the Prompt opens up click stop server this time.


create an .a5w page that displays a Component is to use the  Save Page tool in the Component Builder.

Open the Component you wish to view after publishing for editing by double-clicking on the file name in the Web Projects Control Panel. This will open the Component Builder.

Click the  Save Page button in the Component Builder toolbar. The  Save Page tool will generate an .a5w page and embed the Component on the page.


The Component Builder toolbar
The Save Page dialog presents several options for creating the .a5w page. You can choose to style the page background separately from the Component's style settings. You can also optionally open the HTML editor to edit the .a5w page. The HTML editor is Alpha Anywhere's build-in editor for editing HTML and .a5w pages.

Select Automatically inherit page background from the Component style. Leave the option to open the HTML editor unchecked and click Save Page.


The Save Page dialog
The dialog to save the new .a5w page will open. Enter the file name for the page in the File name field. Click Save when you are done. This will save the new .a5w page containing the Component.


Saving the .a5w page that will contain the Component
The new .a5w page will be saved in the same directory as the Component. Open the Web Projects Control Panel and select the  A5W Pages option in the left column to filter the files shown. You should see the .a5w page you just created in this list.


Viewing all the .a5w pages in the web project
Now that you have an .a5w page containing the Component, the Alpha Anywhere Application can be published. The next step is configuring a Publishing Profile for publishing the application to the local webroot.

Configure the Local Webroot Publishing Profile
The Publishing Profile describes where web application files will be published in the Application Server's webroot, either locally or on a remote server. During the publishing process, the project files for the web application are compiled and copied to the webroot for the Application Server. This section describes how to configure a project to publish an application to the local webroot on the development machine. The publishing process to deploy an application to a web server is similar for both Alpha Anywhere Application Server for IIS and Alpha Anywhere Standard Application Server.

From the Web Projects Control Panel, open the Web menu and select Project Settings... to open the Web Project Profiles dialog.


Opening Project Settings
Select the Local Webroot profile from the list of profiles listed in the left-hand column. This will display the settings for the Local Webroot publishing profile.


Web Project Properties
All files published to the local webroot will be published in the webroot. The webroot is defined in the Alpha Anywhere Development Server settings. Every Alpha Anywhere application you create will be published to the same webroot. To make it easy to disambiguate between projects for testing purposes, you can set the Target Folder property. The Target Folder is a directory inside the webroot. It's considered best practice to name the Target Folder after your project.

Enter a Target Folder for the Local Webroot profile.


Define a Target Folder for the Local Webroot publishing profile
You can optionally define a default page to display after publishing your application. This can be any .a5w page in your project. Define the Default Page for the Local Webroot. Open the dropdown of pages for the Default Page property and choose a default page from the list displayed.


Selecting a Default Page for the Local Webroot publishing profile
Click OK to save the changes you made the Local Webroot publishing profile.


The completed publishing profile
Now that you have configured a publishing profile, the next step is to publish your application and open it in a web browser.

Publish Your Application
Alpha Anywhere web applications are deployed using the  Publish Web Project dialog. Applications can be published locally on your development machine or to a remote server. In addition to deploying your project, publishing is also a useful tool for testing your application. Testing can be done locally on the development machine or on a remote server. The following instructions explain how to publish to the local webroot on the development machine.

From the Web Projects Control Panel, click  Publish on the toolbar.


The Publish Web Project dialog is used to configure what is published to the destination defined by the publishing profile.

Select the Local Webroot publishing profile from the Select profile dropdown. Select the All files in project option to publish all files in the project. Check the boxes for Publish Web Project files and Publish new or modified files only. Check the option to Launch browser after files are published. For the Page to show option, select an .a5w page that will be opened when the browser is launched.

Click the Publish button to publish the project to the local webroot.


Publish Web Project settings
You can optionally check Save these settings as your Quick Publish settings to save the setting as your Quick Publish settings. This is useful if you are making frequent changes you want to test on the local webroot or a remote test server. You can Quick Publish your project by clicking the Quick publish project link below the left column on the Web Projects Control Panel.


The Files to be Published dialog displays the list of files that will be published. This dialog is for informational purposes only. While you can edit the text in the dialog, it does not change which files are published to the webroot.

Click OK to continue.


List of files to be published
If the destination folder does not exist, you will be prompted to create the folder. Click Yes to create the destination folder.


Prompt asking if you would like to create the destination webroot directory
When Alpha Anywhere finishes publishing the application, it will display a message. Click OK.


Notification that publishing is complete
Next, your default web browser will launch and open the .a5w page you selected in the Publish Web Project dialog.

The URL for this page will contain 3 components: "localhost" followed by the port number used to communicate with the Development Server, the folder that was created in the webroot where the project was published, and the .a5w page. You can view other pages in your project by typing the file location relative to the webroot in the address bar. For example, if you have a page named "TabbedUI_Admin.a5w" in the ExampleProject directory in the webroot, you could view this page by typing the following into the address bar:

localhost:8080/ExampleProject/index.a5w