## Triumph 
Triumph is a inventory management system for airplane parts. We build the application with Node.js as an API backend and React.js as the client side facing application. 

##The Tools
**Node.js** is a JavaScript runtime platform based on the V8 engine that's also used in Chrome browsers.

It's single-threaded, but features a compicated event loop for processing of asynchronous events, giving the ability to handle tons of asynchronous tasks at the same time. A Node.js application will perform very poorly if you hog up this single thread. Try using asyncronous flavours of all I/O operations.

**React.js** is a JavaScript library for building user interfaces. React is declarative
Component based. You can develop new features without having to rewriting code, because React is only client side framework.

Make sure to check your Node version
```
node --version
```

## Clone a repository

Use these steps to clone from SourceTree, our client for using the repository command-line free. Cloning allows you to work on your files locally. If you don't yet have SourceTree, [download and install first](https://www.sourcetreeapp.com/). If you prefer to clone from the command line, see [Clone a repository](https://confluence.atlassian.com/x/4whODQ).

1. You’ll see the clone button under the **Source** heading. Click that button.
2. Now click **Check out in SourceTree**. You may need to create a SourceTree account or log in.
3. When you see the **Clone New** dialog in SourceTree, update the destination path and name if you’d like to and then click **Clone**.
4. Open the directory you just created to see your repository’s files.

Now that you're more familiar with your Bitbucket repository, go ahead and add a new file locally. You can [push your change back to Bitbucket with SourceTree](https://confluence.atlassian.com/x/iqyBMg), or you can [add, commit,](https://confluence.atlassian.com/x/8QhODQ) and [push from the command line](https://confluence.atlassian.com/x/NQ0zDQ).

###Before Running the project
**Git**Install =the latest Git for Windows installer [here](https://gitforwindows.org/).
Follow the Next and Finish prompts to complete the installation. The default options are pretty sensible for most users.

Open a Command Prompt (or Git Bash if during installation you elected not to use Git from the Windows Command Prompt).
```
$ git config --global user.name "First Name"
$ git config --global user.email "example@email.com"
```

**NPM & Node.js** Go to the offical node.js [website](https://nodejs.org/en/) donwload the installer as an `<.msi.` file. 
Keep the default settings make sure to pick NPM package manager. 
Open up Command Prompt and run `<npm -v>` and `<node -v>`to check if it is installed properlly, should return the version numbers. 

Next `<git clone your repo>` onto your machine. 

##Deployment

**Development**

[**Docker**](https://docs.docker.com/get-started/)

**Test**

[**Heroku:Vanilla**](https://devcenter.heroku.com/categories/nodejs-support) 

[**Heroku:Docker**](https://devcenter.heroku.com/categories/deploying-with-docker)
Heroku allows for two different strategies to deploy your applicaiton with [Docker](https://docs.docker.com/get-started/).

**Production**

[**Alpha Anywhere**](https://documentation.alphasoftware.com/documentation/pages/GettingStarted/index.html)

The Alpha Anywhere system has two ways to deploy applications. In this example we will be going over the Anywhere Application Server, the docs from Alpha Anywhere are available [here](https://documentation.alphasoftware.com/pages/Guides/Application%20Server/Server%20Settings/index.xml)

Download Alpha Anywhere you should receive that via email with a license number. 

Once downloaded, open up the Alpha Anywhere desktop application. The first thing you should see a black screen that looks like a black screen. 

￼￼￼[Inital Screen](Documentation/images/initailscreen.png)

Click on the Recent Workspaces tab and a prompt asking you to create a new workspace should pop up. 

￼[Prompt](Documentation/images/prompt.png)

The prompt will ask you if you would like to enter the Control Panel click Yes. 
Once in the Web Projects Control Panel on the top tab click the Web line and Start the Development Server. 


￼[Development Server](Documentation/images/devserver.png)

A HTTOP Demo Server should be deployed and you should go ahead and press start server. 

￼[Start Server](Documentation/images/startServer1.png)

If prompted, click Yes to confirm the action.

￼[Start Server](Documentation/images/startServer2.png)

If you want to Stop the server go back and the the same steps as starting but when the Prompt opens up click stop server this time.


