import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux'
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import store from './Store/Store'
import {AuthActions} from './Store/Actions/AllActions'
import { Router, Route, IndexRoute, browserHistory } from 'react-router';


import Login from './Components/Login/Login';
import Dashboard from "./Components/AdminDashboard/Dashboard"
import AddProduct from './Components/AddRecords/AddProduct'
import ViewProducts from './Components/Reports/ViewProducts'
import AddSale from './Components/AddRecords/AddSale'
import AddStore from './Components/AddRecords/AddStore'
import ViewStores from './Components/Reports/ViewStores'
import ViewSales from './Components/Reports/ViewSales';
import Stock from './Components/Stock/Stock'

ReactDOM.render(
<MuiThemeProvider>
  <Provider store={store}>
    <Router history={browserHistory} >
      <Route path="/home" component={Dashboard} >
       
       <Route path="add-product" component={AddProduct} > </Route>
       <Route path="add-purchase" component={AddPurchase} > </Route>
       <Route path="add-sale" component={AddSale} > </Route>
       <Route path="add-store" component={AddStore} > </Route>
       <Route path="view-products" component={ViewProducts} > </Route>
       <Route path="view-purchases" component={ViewPurchases} > </Route>
       <Route path="view-sales" component={ViewSales} > </Route>
       <Route path="view-stores" component={ViewStores} > </Route>
       <Route path="view-stock" component={Stock} > </Route>
       <IndexRoute component={Stock} > </ IndexRoute>
       </Route>

       <Route path="/" component={Login} > </Route>
       <Route path="/login" component={Login} > </Route>
    </Router>
  </ Provider>
</ MuiThemeProvider>
  ,
  document.getElementById('root')
);

